/**
 * Reduce duplicate characters to a desired minimum
 */
exports.reduceString = function(str, amount) {
};

/**
 * Wrap lines at a given number of columns without breaking words
 */
exports.wordWrap = function(str, cols) {
};

/**
 * Reverse a String
 */
exports.reverseString = function(str) {
};

/**
 * Check if String is a palindrome
 */
exports.palindrome = function(str) {
};
