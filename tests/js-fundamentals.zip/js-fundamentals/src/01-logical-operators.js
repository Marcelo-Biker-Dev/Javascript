/**
 * logical OR
 */
exports.or = function(a, b) {
   return a || b;
};

/**
 * logical AND
 */
exports.and = function(a, b) {
    return a && b;
};
